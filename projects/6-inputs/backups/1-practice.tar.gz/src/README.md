# Requirements

Write a program that disables key repeat and prints a message only once when the Z key is pressed. Also print another message when the physical Z key is pressed using its scan code. Run the program and test the difference on your keyboard layout.

