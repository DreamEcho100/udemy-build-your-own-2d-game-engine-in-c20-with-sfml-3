# Requirements

Write a program that shows a rectangle on screen. While the Space key is being held, the rectangle should switch to a different fill color. When the Space key is released, the rectangle should return to its original color.

