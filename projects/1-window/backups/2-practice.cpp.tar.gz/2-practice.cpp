// Write a program that creates a window sized 900 by 600 and enables vertical sync. Print to the
// terminal whether the window currently has focus or not using window.hasFocus(). Keep the window
// responsive and make sure the user can still close it properly.

#include <SFML/Graphics.hpp>
#include <iostream>

int main() {
  sf::RenderWindow window(sf::VideoMode({900, 600}), "Focus Practice");
  window.setVerticalSyncEnabled(true);

  bool prevFocus = false;
  while (window.isOpen()) {
    while (const std::optional<sf::Event> event = window.pollEvent()) {
      if (event->is<sf::Event::Closed>()) {
        window.close();
      }
    }

    bool currFocus = window.hasFocus();
    // Using the following check to print it one time on change only!
    if (currFocus != prevFocus) {
      std::cout << "Window focused: " << currFocus << '\n';
      window.setMouseCursorVisible(currFocus);
      prevFocus = currFocus;
    }

    window.clear();
    window.display();
  }
}
