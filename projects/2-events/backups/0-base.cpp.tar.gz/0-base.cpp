#include <SFML/Graphics.hpp>
#include <iostream>

int main() {
  sf::RenderWindow window(sf::VideoMode({600, 800}), "SFML Window");

  while (window.isOpen()) {
    while (const std::optional event = window.pollEvent()) {
      if (event->is<sf::Event::Closed>()) {
        window.close();
      }

      if (const sf::Event::Resized* resized = event->getIf<sf::Event::Resized>()) {
        std::cout << "Size:" << resized->size.x << "x" << resized->size.y << "\n";
      }

      if (event->is<sf::Event::FocusLost>()) {
        std::cout << "Window lost focus!\n";
      }

      if (event->is<sf::Event::FocusGained>()) {
        std::cout << "Window gained focus!\n";
      }

      if (const auto key = event->getIf<sf::Event::KeyPressed>()) {
        if (key->code == sf::Keyboard::Key::W) {
          std::cout << "\"W\" pressed\n";
        }
      }

      if (const auto key = event->getIf<sf::Event::KeyReleased>()) {
        if (key->code == sf::Keyboard::Key::W) {
          std::cout << "\"W\" released\n";
        }
      }

      if (const auto mouse = event->getIf<sf::Event::MouseButtonPressed>()) {
        std::cout << "Mouse button pressed at";
        std::cout << mouse->position.x << ", " << mouse->position.y << "\n";
      }

      if (const auto scroll = event->getIf<sf::Event::MouseWheelScrolled>()) {
        std::cout << "Scrolled by: " << scroll->delta << "\n";
      }
    }

    window.clear();
    window.display();
  }
}
