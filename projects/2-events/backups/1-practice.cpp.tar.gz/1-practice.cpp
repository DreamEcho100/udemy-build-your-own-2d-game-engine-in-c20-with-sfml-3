// Write a program that uses window.waitEvent() instead of pollEvent(). Print a message for every
// event you receive (for example: “Resized”, “KeyPressed”, “MouseWheelScrolled”, etc.). The program
// should wait for interaction instead of running a continuous loop, and it must still allow the
// window to close properly when requested.

// Open the system task manager or use a terminal command to check the CPU usage of your program
// while it runs with waitEvent(). Then switch back to pollEvent() and observe the difference.
// Explain why one approach may use more CPU than the other.

// - When using pollEvent(), the program continues running the game loop every frame, even if no
// events are happening. This means the CPU is constantly working, which results in higher CPU
// usage.

// - When using waitEvent(), the program pauses and waits for an event before continuing. While
// waiting, the CPU does almost no work, so the usage is much lower.

// In short:

// pollEvent() keeps the application fully active and responsive for real-time rendering and
// animation, but uses more CPU.

// waitEvent() saves CPU by sleeping while nothing happens, but it stops rendering and updating,
// making it unsuitable for real-time gameplay.

#include <SFML/Graphics.hpp>
#include <iostream>

int main() {
  sf::RenderWindow window(sf::VideoMode({600, 800}), "SFML Window");

  while (window.isOpen()) {
    while (const std::optional event = window.waitEvent()) {
      if (event->is<sf::Event::Closed>()) {
        window.close();
      }

      if (const sf::Event::Resized* resized = event->getIf<sf::Event::Resized>()) {
        std::cout << "Size:" << resized->size.x << "x" << resized->size.y << "\n";
      }

      if (event->is<sf::Event::FocusLost>()) {
        std::cout << "Window lost focus!\n";
      }

      if (event->is<sf::Event::FocusGained>()) {
        std::cout << "Window gained focus!\n";
      }

      if (const auto key = event->getIf<sf::Event::KeyPressed>()) {
        if (key->code == sf::Keyboard::Key::W) {
          std::cout << "\"W\" pressed\n";
        }
      }

      if (const auto key = event->getIf<sf::Event::KeyReleased>()) {
        if (key->code == sf::Keyboard::Key::W) {
          std::cout << "\"W\" released\n";
        }
      }

      if (const auto mouse = event->getIf<sf::Event::MouseButtonPressed>()) {
        std::cout << "Mouse button pressed at";
        std::cout << mouse->position.x << ", " << mouse->position.y << "\n";
      }

      if (const auto scroll = event->getIf<sf::Event::MouseWheelScrolled>()) {
        std::cout << "Scrolled by: " << scroll->delta << "\n";
      }
    }

    window.clear();
    window.display();
  }
}
